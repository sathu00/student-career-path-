from flask import Flask, render_template, request
from sklearn.tree import DecisionTreeClassifier
import numpy as np

app = Flask(__name__)

class CareerGuidanceSystem:
    def __init__(self):
        # Sample training data
        self.training_data = [
            # Features: Q1, Q2, Q3 | Label: Career
            (1, 1, 1, "Software Developer"),
            (0, 1, 0, "Accountant"),
            (0, 1, 1, "Sales Representative"),
            # Add more training data as needed
        ]

        # Separate features and labels
        self.features = np.array([item[:-1] for item in self.training_data])
        self.labels = [item[-1] for item in self.training_data]

        # Create a decision tree classifier
        self.model = DecisionTreeClassifier()
        self.model.fit(self.features, self.labels)

    def get_career_recommendation(self, answers):
        # Convert user answers to feature vector
        user_input = np.array([int(answers[f"Q{i}"].lower() == 'yes') for i in range(1, len(answers) + 1)])

        # Reshape the input to match the expected number of features
        user_input = user_input.reshape(1, -1)

        # Use the trained model to predict the career
        predicted_career = self.model.predict(user_input)[0]
        return predicted_career

career_system = CareerGuidanceSystem()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/recommendation', methods=['POST'])
def recommendation():
    answers = request.form.to_dict()
    career_recommendation = career_system.get_career_recommendation(answers)
    return render_template('recommendation.html', recommendation=career_recommendation)

if __name__ == '__main__':
    app.run(debug=True)
